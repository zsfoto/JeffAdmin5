				<div class="row">
					<div class="col-xl-12">
						<div class="breadcrumb-holder pt-1 pb-2">
							<a role="button" href="#" class="btn btn-warning mt-1 me-1"><span class="btn-label"><i class="fa fa-eye"></i></span>Megnéz</a>
							<a role="button" href="#" class="btn btn-success mt-1 me-1"><span class="btn-label"><i class="fa fa-plus"></i></span>Új felvitele</a>
							<a role="button" href="#" class="btn btn-primary mt-1 me-1"><span class="btn-label"><i class="fa fa-edit"></i></span>Módosítás</a>
							<a role="button" href="#" class="btn btn-danger  mt-1 me-1"><span class="btn-label"><i class="fa fa-minus"></i></span>Töröl</a>
						</div>
					</div>
				</div>
