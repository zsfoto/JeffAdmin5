<?php 
use Cake\Core\Configure;
$prefix = strtolower( $this->request->getParam('prefix') ?? '' );

if($prefix == null || $prefix == ''){
	$prefix = 'main';
}
$controller = $this->request->getParam('controller');
$action = $this->request->getParam('action');
$sidebarMenu = Configure::read('Theme.' . $prefix . '.sidebarMenu');

$onlySuperAdmin = false;	// A login után kiderül, hogy az illető superadmin-e.
$cakeDC = false;
if($controller == 'Users'){
	$cakeDC = true;
}

?>

	<!-- Left Sidebar -->
	<div class="left main-sidebar">	
		<div class="sidebar-inner leftscroll">
			<div id="sidebar-menu">
				<ul>
<?php foreach($sidebarMenu as $prefix => $menus){ ?>
<?php 	foreach($menus as $menu){ ?>
<?php		if($menu['type'] == 'menu'){ ?>
					<li class="submenu">
						<a href="<?= $this->Url->build(['prefix' => $prefix, 'controller' => $menu['controller'], 'action' => $menu['action']], ['fullBase' => true]) ?>"><i class="fa fa-fw fa-bars"></i><span> <?= $menu['title'] ?> </span> </a>
					</li>
<?php 		} // foreach menu: OK?>


<?php		if($menu['type'] == 'submenu'){ ?>
					<li class="submenu">
<?php
						foreach($menu['items'] as $submenu){
							$class = '';
							if ($submenu['controller'] == $controller) {
								$class = ' class="active"';
								break;
							}
						}
?>
					
					<a href="#"<?= $class ?>><i class="<?= $menu['icon'] ?>"></i> <span> <?= $menu['title'] ?> </span> <span class="menu-arrow"></span></a>
						<ul class="list-unstyled">
<?php $active= '' ?>
<?php			foreach($menu['items'] as $submenu){ ?>
<?php 				
					$class = '';
					if ($submenu['controller'] == $controller) {
						$class = ' class="active"';
					}
					
?>

							<li<?= $class ?>><a href="<?= $this->Url->build(['prefix' => $prefix, 'controller' => $submenu['controller'], 'action' => $submenu['action']], ['fullBase' => true]) ?>"><?= $submenu['title'] ?></a></li>
<?php			} ?>

						</ul>
					</li>
<?php 		} // foreach submenu?>


<?php 	} ?>

<?php } ?>

				</ul>
				<div class="clearfix"></div>
			</div>        
			<div class="clearfix"></div>
		</div>
	</div>
	<!-- End Sidebar -->
