	<footer class="footer">
		<div class="float-start">
			Copyright <a target="_blank" href="#">Jeff Admin 2</a>
		</div>
		<div class="float-end">
			Powered by <a target="_blank" href="https://www.vzsfoto.hu"><b>Jeff Shoemaker</b></a>
		</div>
	</footer>
