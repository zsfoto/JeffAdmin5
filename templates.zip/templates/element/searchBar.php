				<div class="collapse" id="collapseSearch">
				  <div class="card card-body mb-3 mt-0">
					<div class="input-group">
						<button class="btn btn-outline-secondary" type="button" id="button-search"><i class="fa fa-fw fa-search"></i> Keresés</button>
						<input id="search" type="text" class="form-control" placeholder="" aria-label="Example text with button addon" aria-describedby="button-addon1">
					</div>
				  </div>
				</div>					
