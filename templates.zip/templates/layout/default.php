<?php use Cake\Core\Configure; ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<?= $this->Html->charset() ?>
	
	<?= $this->Html->meta('csrfToken', $this->request->getAttribute('csrfToken')) ?>
	
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<title>The New Pike Admin - Free Bootstrap 5 Admin Template</title>
	<meta name="description" content="Free Bootstrap 5.3.2 Admin Theme | Jeff Admin">
	<meta name="author" content="Jeff Web Development - https://www.vzsfoto.hu">
	<?= $this->Html->meta('favicon.ico', 'jeffAdmin5./assets/images/favicon.ico', ['type' => 'icon']) ?>
	
	<?= $this->Html->css([
		'jeffAdmin5./assets/css/bootstrap.min',
		'jeffAdmin5./assets/font-awesome/css/font-awesome.min',
		'jeffAdmin5./assets/plugins/jquery-toastmessage-plugin-master/src/main/resources/css/jquery.toastmessage',
		'jeffAdmin5./assets/plugins/sweetalert2/dist/sweetalert2.min',
	]); ?>
	
	<?= $this->fetch('css') ?>

	<?= $this->Html->css('jeffAdmin5./assets/css/style'); ?>
	
	
<?php /*
	<!-- FORM -->
	<link href="assets/plugins/select2-4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" type="text/css" />		
	<link href="assets/css/select2-bootstrap-5-theme.min.css" rel="stylesheet" type="text/css" />
	<link href="assets/plugins/summernote-0.8.18-dist/summernote-lite.min.css" rel="stylesheet" type="text/css" />
	<link href="/assets/plugins/tempus-dominus-6.0.0/dist/css/tempus-dominus.min.css" rel="stylesheet" type="text/css" />
	<!-- /.FORM -->
*/ ?>

</head>

<body class="adminbody" style="background: #e7e2d8;">

<?= $this->Flash->render() ?>

<div id="main">

	<?= $this->element("jeffAdmin5.header") ?>

	<?= $this->element("jeffAdmin5.leftSidebar") ?>

    <div class="content-page">
        <div class="content"><!-- Start content -->            
			<div class="container-fluid">
				<?= $this->element("jeffAdmin5.breadcrumbBar") ?>
				
				<?= $this->element("jeffAdmin5.searchBar") ?>

				<?= $this->fetch('content') ?>
	
            </div><!-- END container-fluid -->
		</div><!-- END content -->
    </div><!-- END content-page -->
    
	<?= $this->element("jeffAdmin5.footer") ?>

</div>
<!-- END main -->

	<?= $this->Html->script([
		'jeffAdmin5./assets/js/jquery.min.js',
		'jeffAdmin5./assets/js/moment-with-locales',
		'jeffAdmin5./assets/js/bootstrap.bundle.min',
		'jeffAdmin5./assets/js/detect',
		'jeffAdmin5./assets/js/fastclick',
		'jeffAdmin5./assets/js/jquery.nicescroll',
		'jeffAdmin5./assets/plugins/jquery-toastmessage-plugin-master/src/main/javascript/jquery.toastmessage',
		'jeffAdmin5./assets/plugins/sweetalert2/dist/sweetalert2.all.min',
	]); ?>

	<?= $this->Html->script('jeffAdmin5./assets/js/pikeadmin') ?>

<?php /*
<!-- FORM -->
<script src="assets/plugins/select2-4.1.0-rc.0/dist/js/select2.full.min.js"></script>
<script src="assets/plugins/select2-4.1.0-rc.0/dist/js/i18n/hu.js"></script>
<script src="assets/plugins/summernote-0.8.18-dist/summernote-lite.min.js"></script>
<script src="assets/plugins/summernote-0.8.18-dist/lang/summernote-hu-HU.js"></script>
<script src="assets/plugins/bootstrap-input-spinner-bs-5/src/bootstrap-input-spinner.js"></script>
<script src="/assets/js/popper.js"></script>	
<script src="/assets/plugins/tempus-dominus-6.0.0/dist/js/tempus-dominus.min.js"></script>
<script src="/assets/plugins/jReadMore-master/dist/read-more.min.js"></script>
<!-- /.FORM -->
*/ ?>

<?= $this->fetch('javaScriptBottom'); ?>

<script>

	$(function () {
		$('[data-bs-toggle="tooltip"]').tooltip()

		$('#collapseSearch').on('shown.bs.collapse', function () {
			$("#search").focus();
		});
	});

</script>
	
<?= $this->fetch('scriptBottom'); ?>

<script>
	$(function () {
		$(".card-body").animate({opacity: 1}, 500);
	});
</script>

<?php /*

<script>

	Swal.fire({
	  title: 'Error!',
	  text: 'Do you want to continue',
	  icon: 'error',
	  confirmButtonText: 'Cool'
	})


	$(function () {
		
		// ToastMessage
		// https://github.com/akquinet/jquery-toastmessage-plugin
		$().toastmessage('showNoticeToast', 'some message here');
		
		$().toastmessage('showToast', {
			text     : 'Hello World',
			stayTime : 5000,
			//sticky   : true,
			position : 'top-right',
			type     : 'success',		// notice, success, warning, error
			close    : function () {
				//console.log("toast is closed ...");
			}
		});	
		
		
		
		// --------------------- FORM --------------------------
		
		// Select2:
		$('.select2').select2({
			theme: 'bootstrap-5',
			placeholder: 'Kérem válasszon...'
		});		
		
		$('.select-multi').select2({	// A multinál nem jó a bootstrap css, ezért marad az alap.
			//theme: 'bootstrap',	// Itt nem kell a stílus, mert eddig nincs jó az 5-öshöz...
			placeholder: 'Kérem válasszon...'
		});		

		$('.select2').on('select2:open', function (e) {
			//console.log('Open');
			//$('.select2-container .select2-selection--multiple').css('height', 75);
		});		

		// Summernote:
		// https://summernote.org/getting-started/#installation
		$('#summernote').summernote({
			placeholder: 'Ide írhatja a megjegyzést...',
			tabsize: 2,
			height: 400,
			lang: 'hu-HU' // default: 'en-US'
		});

		// Spinner
		// file:///D:/www/My/www/PikeAdmin/src/assets/plugins/bootstrap-input-spinner-bs-5/index.html
		$("input[type='number']").inputSpinner()


		// Show More text
		$('.read-more').readMore({
			readMoreHeight: 70,
			readMoreText: "több...",
			readLessText: "...kevesebb"
		});
		
		// ------------------- /.FORM --------------------------

	});


	// DateTime picker
	const datetimepicker = new tempusDominus.TempusDominus(document.getElementById('datetimepicker'), {
		localization: { locale: 'hu', format: 'L LTS', dayViewHeaderFormat: { month: 'long', year: 'numeric' }},
		display: {
			//dayViewHeaderFormat: { month: 'long', year: '4-digit' },	
			icons: {type: 'icons', time: 'fa fa-clock-o', date: 'fa fa-calendar', up: 'fa fa-arrow-up', down: 'fa fa-arrow-down', previous: 'fa fa-chevron-left', next: 'fa fa-chevron-right', today: 'fa fa-calendar-check-o', clear: 'fa fa-times', close: 'fa fa-check'},
			sideBySide: true,
	        buttons: { today: true, clear: true, close: true},
			components: {calendar: true, date: true, month: true, year: true, decades: true, clock: true, hours: true, minutes: true, seconds: true, useTwentyfourHour: true},			
		},
	});
	datetimepicker.dates.setValue(datetimepicker.dates.parseInput(new Date(moment('2013-02-17 21:23:42', 'YYYY-MM-DD HH:mm:ss'))), datetimepicker.dates.lastPickedIndexs);



	// Date picker
	const datepicker = new tempusDominus.TempusDominus(document.getElementById('datepicker'), {
		localization: {locale: 'hu', format: 'L', dayViewHeaderFormat: { month: 'long', year: 'numeric' } },
		display: {
			icons: {type: 'icons', time: 'fa fa-clock-o', date: 'fa fa-calendar', up: 'fa fa-arrow-up', down: 'fa fa-arrow-down', previous: 'fa fa-chevron-left', next: 'fa fa-chevron-right', today: 'fa fa-calendar-check-o', clear: 'fa fa-times', close: 'fa fa-check'},
			buttons: {today: true, clear: true,close: true},
			components: { calendar: true, date: true, month: true, year: true, decades: true, clock: false, hours: false, minutes: false, seconds: false, useTwentyfourHour: undefined},			
		},
	});
	datepicker.dates.setValue(datepicker.dates.parseInput(new Date(moment('2019-08-27', 'YYYY-MM-DD'))), datepicker.dates.lastPickedIndexs);



	// Time picker
	const timepicker = new tempusDominus.TempusDominus(document.getElementById('timepicker'), {
		localization: {locale: 'hu', format: 'LTS'},
		display: {
			//viewMode: 'clock',
			icons: { type: 'icons', time: 'fa fa-clock-o', date: 'fa fa-calendar', up: 'fa fa-arrow-up', down: 'fa fa-arrow-down', previous: 'fa fa-chevron-left', next: 'fa fa-chevron-right', today: 'fa fa-clock-o', clear: 'fa fa-times', close: 'fa fa-check' },
			buttons: {today: true, clear: true, close: true},
			components: {decades: false, year: false, month: false, date: false, hours: true, minutes: true, seconds: true},			
		},		
	});
	//const parsedDate = timepicker.dates.parseInput(new Date(0, 0, 0, 12, 23, 45));
	let time = '14:37:49';
	timepicker.dates.setValue(timepicker.dates.parseInput(new Date(moment('2000-01-01 ' + time, 'YYYY-MM-DD HH:mm:ss'))), timepicker.dates.lastPickedIndexs);

</script>
<!-- END Java Script for this page -->
*/ ?>


</body>
</html>
